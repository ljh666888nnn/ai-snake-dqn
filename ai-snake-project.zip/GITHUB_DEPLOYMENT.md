# 🚀 GitHub部署指南

本指南将帮助你将AI贪吃蛇项目上传到GitHub并进行版本管理。

## 📋 准备工作

### 1. 确保已安装Git
```bash
git --version
```

### 2. 配置Git用户信息（如果尚未配置）
```bash
git config --global user.name "你的用户名"
git config --global user.email "your.email@example.com"
```

## 🌐 创建GitHub仓库

### 步骤1：登录GitHub
1. 访问 [GitHub.com](https://github.com)
2. 登录你的账户

### 步骤2：创建新仓库
1. 点击右上角的 `+` 号
2. 选择 `New repository`
3. 填写仓库信息：
   - **Repository name**: `ai-snake-dqn` 或 `intelligent-snake-game`
   - **Description**: `🐍 AI贪吃蛇 - 基于深度强化学习的智能游戏AI`
   - **Visibility**: 选择 `Public` 或 `Private`
   - **不要**勾选 `Add a README file`（我们已经有了）
   - **不要**勾选 `Add .gitignore`（我们已经有了）
   - **不要**选择 `Choose a license`（我们已经有了）

### 步骤3：获取仓库URL
创建完成后，GitHub会显示仓库URL，类似：
```
https://github.com/yourusername/ai-snake-dqn.git
```

## 📤 推送项目到GitHub

### 当前项目状态
项目已经完成了本地Git初始化：
- ✅ Git仓库已初始化
- ✅ 文件已添加到暂存区
- ✅ 首次提交已完成
- ✅ .gitignore文件已配置
- ✅ README.md已创建
- ✅ LICENSE文件已添加

### 连接远程仓库并推送

```bash
# 添加远程仓库（替换为你的实际URL）
git remote add origin https://github.com/yourusername/ai-snake-dqn.git

# 推送到GitHub
git push -u origin master
```

如果遇到权限问题，可能需要：

#### 选项A：使用个人访问令牌（推荐）
1. 在GitHub上生成Personal Access Token：
   - 设置 → Developer settings → Personal access tokens → Tokens (classic)
   - 选择适当的权限（至少需要 `repo` 权限）
2. 使用令牌作为密码进行推送

#### 选项B：使用SSH密钥
```bash
# 生成SSH密钥
ssh-keygen -t rsa -b 4096 -C "your.email@example.com"

# 添加SSH密钥到ssh-agent
ssh-add ~/.ssh/id_rsa

# 将公钥添加到GitHub账户
# 然后使用SSH URL
git remote set-url origin git@github.com:yourusername/ai-snake-dqn.git
git push -u origin master
```

## 📝 后续维护

### 添加新功能或修复
```bash
# 创建新分支
git checkout -b feature/new-feature

# 进行修改...

# 提交更改
git add .
git commit -m "feat: 添加新功能描述"

# 推送分支
git push origin feature/new-feature

# 在GitHub上创建Pull Request
```

### 常用Git命令
```bash
# 查看状态
git status

# 查看提交历史
git log --oneline

# 创建新的提交
git add .
git commit -m "update: 描述你的更改"
git push

# 同步远程更改
git pull origin master
```

## 🏷️ 版本标签

为重要的版本创建标签：
```bash
# 创建标签
git tag -a v1.0.0 -m "v1.0.0: 初始发布版本"

# 推送标签
git push origin v1.0.0

# 推送所有标签
git push origin --tags
```

## 📊 GitHub功能利用

### 1. Issues管理
- 创建Issues来跟踪bug和功能请求
- 使用标签分类Issues
- 关联Pull Request和Issues

### 2. Projects看板
- 创建项目看板来管理开发进度
- 使用看板跟踪功能开发状态

### 3. Actions自动化
- 设置GitHub Actions进行CI/CD
- 自动运行测试和部署

### 4. Releases发布
- 创建正式发布版本
- 附加编译好的模型文件
- 编写发布说明

## 🔗 示例仓库信息

完成上传后，你的GitHub仓库将包含：

```
📁 your-username/ai-snake-dqn
├── 📄 README.md              # 项目主页
├── 📄 .gitignore             # Git忽略文件
├── 📄 LICENSE                # MIT许可证
├── 📄 requirements.txt       # Python依赖
├── 🐍 agent.py              # DQN智能体
├── 🧠 model.py              # 神经网络模型
├── 🎮 snake_game.py         # 游戏环境
├── 🏃‍♂️ train.py              # 训练脚本
├── 🎯 play.py               # 游戏演示
├── 📊 visualize.py          # 可视化工具
├── 🛠️ utils.py              # 工具函数
├── 📁 model/                # 训练好的模型
├── 📁 plots/                # 训练图表
└── 📁 docs/                 # 项目文档
```

## 🎉 完成部署

部署完成后，你可以：

1. **分享项目**: 发送GitHub链接给朋友
2. **协作开发**: 邀请其他开发者参与
3. **持续改进**: 根据反馈不断优化
4. **展示成果**: 在简历或作品集中展示

## 🆘 常见问题

### Q: 推送时提示权限被拒绝
A: 检查GitHub用户名、密码或SSH密钥配置

### Q: 文件太大无法推送
A: 检查.gitignore，确保大文件被忽略

### Q: 提交历史混乱
A: 考虑使用`git rebase`重新整理提交历史

### Q: 想要更改仓库名称
A: 在GitHub仓库设置中可以重命名

---

🎯 **现在你的AI贪吃蛇项目已经准备好上传到GitHub了！** 